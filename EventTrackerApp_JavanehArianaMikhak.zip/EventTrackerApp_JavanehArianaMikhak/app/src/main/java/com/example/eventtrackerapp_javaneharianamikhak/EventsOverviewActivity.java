package com.example.eventtrackerapp_javaneharianamikhak;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EventsOverviewActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEvents;
    private EventAdapter eventAdapter;
    private List<String> eventList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_overview);

        recyclerViewEvents = findViewById(R.id.recyclerViewEvents);
        recyclerViewEvents.setLayoutManager(new LinearLayoutManager(this));

        // Sample event data
        eventList = new ArrayList<>();
        eventList.add("Doctor Appointment – June 5");
        eventList.add("Parent-Teacher Meeting – June 6");
        eventList.add("Soccer Game – June 7");

        eventAdapter = new EventAdapter(eventList);
        recyclerViewEvents.setAdapter(eventAdapter);
    }

    class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
        private List<String> items;

        EventAdapter(List<String> items) {
            this.items = items;
        }

        class EventViewHolder extends RecyclerView.ViewHolder {
            TextView eventText;
            Button deleteButton;

            EventViewHolder(View view) {
                super(view);
                eventText = view.findViewById(R.id.eventText);
                deleteButton = view.findViewById(R.id.deleteButton);
            }
        }

        @Override
        public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_event, parent, false);
            return new EventViewHolder(view);
        }

        @Override
        public void onBindViewHolder(EventViewHolder holder, int position) {
            String event = items.get(position);
            holder.eventText.setText(event);
            holder.deleteButton.setOnClickListener(v -> {
                items.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, items.size());
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
}
