package com.example.eventtrackerapp_javaneharianamikhak;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameText, passwordText;
    private Button buttonLogin, buttonRegister;
    private TextView textFeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameText = findViewById(R.id.editTextUsername);
        passwordText = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textFeedback = findViewById(R.id.textFeedback);

        // Disable login until both fields have input
        TextWatcher loginWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonLogin.setEnabled(
                        !usernameText.getText().toString().trim().isEmpty() &&
                                !passwordText.getText().toString().trim().isEmpty()
                );
            }
            @Override public void afterTextChanged(Editable s) {}
        };

        usernameText.addTextChangedListener(loginWatcher);
        passwordText.addTextChangedListener(loginWatcher);

        buttonLogin.setOnClickListener(v -> {
            String username = usernameText.getText().toString().trim();
            Intent intent = new Intent(MainActivity.this, EventsOverviewActivity.class);
            startActivity(intent);
        });

        buttonRegister.setOnClickListener(v -> {
            String username = usernameText.getText().toString().trim();
            textFeedback.setText("Account created for: " + username);
        });

    }
}
